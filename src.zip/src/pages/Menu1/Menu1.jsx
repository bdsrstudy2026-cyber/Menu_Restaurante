import "./Menu1.css";

function Menu1() {
return (
<div className="inicio">
<h1>Menu 1</h1>

<p>
Sistema de Menus
</p>
</div>
);
}

export default Menu1;
